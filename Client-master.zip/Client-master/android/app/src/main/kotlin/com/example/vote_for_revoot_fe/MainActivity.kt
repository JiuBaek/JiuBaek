package com.example.vote_for_revoot_fe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
